/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package time;

import java.util.ArrayList;

/**
 *
 * @author MI COMPUTADORA
 */
public abstract class Time {
    private long init, finish, total;
    int[] a=new int[2];

    public Time(long init, long finish){
            this.init = init;
            this.finish = finish;
    }
    public long initTime(){	
        init = System.currentTimeMillis();
        return init;
    }
    public long finishTime(){		
        finish = System.currentTimeMillis();
        return finish;
    }
    public long getTime(){	
        total=finish-init;
        System.out.println("Tiempo de ejecución en milisegundos: " + total); //Mostramos en pantalla el tiempo de ejecución en milisegundos
        return total;
    }
    // Se consultó como medir el tiempo de ejecución de la siguiente página web 
    //https://unestudiantedeinformatica.blogspot.com/2014/07/medir-el-tiempo-de-ejecucion-en-java.html
}
