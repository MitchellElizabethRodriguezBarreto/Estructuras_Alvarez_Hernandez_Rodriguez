package Proyecto;

import java.awt.Rectangle;

public class Main {
	
	// Se crea el atributo de mismo como un objeto
	private static Main main;
	
	// este es el constructor es privado
	private Main() {
		
	}
	
	// este es el contructor del constructor 	
	// Revisa si ya esta creado, si lo esta entonces lo retorna	
	public static Main getInstance() {
		if(main==null) {
			main = new Main();
		}
		return main;
	}
	
	private void run() {
		
	}
	
	public static void main(String[] args) {
		Fly este = new Fly(Destination.CALI, 10, 25);
		System.out.println(este.getCity());
		System.out.println(este.getPrice());
		System.out.println(este.getChairs().getChair(29));
		System.out.println(este.getHour()[0] + ":" + este.getHour()[1]);
	}
	
}