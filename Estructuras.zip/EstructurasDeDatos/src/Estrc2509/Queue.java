package Estrc2509;

public class Queue<T> implements IQueue<T>{
	
	private int size;
	private DoubleNode<T> head;
	private	DoubleNode<T> tail;
	
	public Queue() {
		this.size = 0;
		this.head = null;
		this.tail = null;
	
	}

	@Override
	public void enQueue(DoubleNode<T> node) {
		if(this.isEmpty()) {
			this.head = node;
		}
		node.setNext(null);
		node.setPrev(this.tail);
		this.tail = node;
		size++;
	}

	@Override
	public void deQueue(DoubleNode<T> node) {
		if(this.isEmpty()) {
			System.out.println("La lista esta vacia!!!");
			return;
		}
		this.head = this.head.getNext();
		this.head.setPrev(null);
		size--;
	}

	@Override
	public boolean isEmpty() {
		if(this.head == null && this.tail == null){
			return true;			
		}
		return false;
	}

	@Override
	public DoubleNode<T> peek() {
		return this.head;
	}
	
}
