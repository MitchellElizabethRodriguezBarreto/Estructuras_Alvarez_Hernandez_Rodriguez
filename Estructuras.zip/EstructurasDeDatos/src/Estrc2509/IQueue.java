package Estrc2509;

public interface IQueue<T> {
	
	// encolar un elemento
	void enQueue(DoubleNode<T> node);
	
	// desencolar un elemento
	void deQueue(DoubleNode<T> node);
	
	// saber si quedan elementos
	boolean isEmpty();
	// saber el primer elemento
	public DoubleNode<T> peek();
}

