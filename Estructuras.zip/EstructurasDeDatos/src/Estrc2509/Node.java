package Estrc2509;

public class Node<T> {

//	se instancia Nodo "minodo" <tipo de dato> = new Nodo<tipo de dato>();
	
	private T key;
	private Node<T> next;
	
	public Node(T key, Node<T> top) {
		this.key = key;
		this.next = top;
	}

	public Node(T key) {
		this.key = key;
	}
	
	void setKey(T key) {
		this.key = key;
	}

	void setNext(Node <T> top) {
		this.next = top;
	}
	
	T getKey() 			{return this.key;}
	Node<T> getNext() 	{return this.next;}

	
	public static void main(String[] args) {
		Node<String> instanceOne = new Node<String>("wey",null);
	}

}


