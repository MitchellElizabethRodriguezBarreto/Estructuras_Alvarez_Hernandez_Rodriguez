
public class Data <T>{
	Data<T> next;
	Data<T> prev;
	T value;
	
	public Data (T info) {
		this.value = info;
	}
}
